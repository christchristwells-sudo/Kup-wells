package com.wells.messagebackup;

import android.app.Notification;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.os.Bundle;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class WhatsAppNotificationListener extends NotificationListenerService {
    private static final String PREFS = "message_archive";
    private static final String KEY = "items";
    private static final int MAX_ITEMS = 2000;

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        // Only archive notifications from the official WhatsApp package.
        if (!"com.whatsapp".equals(sbn.getPackageName())) return;

        Notification notification = sbn.getNotification();
        if (notification == null || notification.extras == null) return;

        Bundle extras = notification.extras;
        CharSequence titleCs = extras.getCharSequence(Notification.EXTRA_TITLE);
        CharSequence textCs = extras.getCharSequence(Notification.EXTRA_BIG_TEXT);
        if (textCs == null) textCs = extras.getCharSequence(Notification.EXTRA_TEXT);

        String title = titleCs == null ? "" : titleCs.toString().trim();
        String body = textCs == null ? "" : textCs.toString().trim();

        // If Android hides the preview, there is no message body to save.
        if (body.isEmpty()) return;

        long timestamp = sbn.getPostTime();
        String readable = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault())
                .format(new Date(timestamp));

        try {
            android.content.SharedPreferences prefs =
                    getSharedPreferences(PREFS, MODE_PRIVATE);
            JSONArray oldItems = new JSONArray(prefs.getString(KEY, "[]"));
            JSONArray newItems = new JSONArray();

            // Keep the most recent entries and cap storage.
            int start = Math.max(0, oldItems.length() - (MAX_ITEMS - 1));
            for (int i = start; i < oldItems.length(); i++) newItems.put(oldItems.get(i));

            JSONObject item = new JSONObject();
            item.put("title", title);
            item.put("body", body);
            item.put("time", readable);
            item.put("timestamp", timestamp);
            newItems.put(item);

            prefs.edit().putString(KEY, newItems.toString()).apply();
        } catch (Exception ignored) {
            // A malformed old entry must not crash notification handling.
        }
    }
}
