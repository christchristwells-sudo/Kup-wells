package com.wells.messagebackup;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.provider.Settings;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private LinearLayout list;
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(28, 32, 28, 32);
        scroll.addView(page);

        TextView heading = new TextView(this);
        heading.setText("WELLS MESSAGE BACKUP");
        heading.setTextSize(22);
        heading.setTextColor(0xFF17345B);
        page.addView(heading);

        TextView explanation = new TextView(this);
        explanation.setText("\nArchive local des notifications WhatsApp reçues. "
                + "L'archivage commence uniquement après activation volontaire de l'accès aux notifications. "
                + "Utilise cette fonction avec l'accord de la personne concernée.\n");
        explanation.setTextSize(15);
        page.addView(explanation);

        Button enable = new Button(this);
        enable.setText("Activer l'accès aux notifications");
        enable.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)));
        page.addView(enable);

        status = new TextView(this);
        status.setTextSize(14);
        status.setPadding(0, 12, 0, 12);
        page.addView(status);

        Button refresh = new Button(this);
        refresh.setText("Actualiser l'archive");
        refresh.setOnClickListener(v -> showMessages());
        page.addView(refresh);

        Button clear = new Button(this);
        clear.setText("Effacer toute l'archive");
        clear.setOnClickListener(v -> new android.app.AlertDialog.Builder(this)
                .setTitle("Effacer l'archive ?")
                .setMessage("Cette action est définitive.")
                .setNegativeButton("Annuler", null)
                .setPositiveButton("Effacer", (d, w) -> {
                    getSharedPreferences("message_archive", MODE_PRIVATE).edit().clear().apply();
                    showMessages();
                }).show());
        page.addView(clear);

        TextView privacy = new TextView(this);
        privacy.setText("\nConfidentialité : les éléments sont conservés sur cet appareil. "
                + "Cette version ne transmet pas les archives à un serveur. "
                + "Elle ne récupère pas les messages antérieurs à son activation et ne garantit pas "
                + "les notifications masquées, regroupées ou absentes.");
        privacy.setTextSize(12);
        privacy.setTextColor(0xFF555555);
        page.addView(privacy);

        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(0, 20, 0, 0);
        page.addView(list);

        setContentView(scroll);
        showMessages();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (status != null) {
            status.setText("Accès aux notifications : "
                    + (isListenerEnabled() ? "activé" : "non activé"));
        }
        if (list != null) showMessages();
    }

    private boolean isListenerEnabled() {
        String enabled = Settings.Secure.getString(getContentResolver(),
                "enabled_notification_listeners");
        return enabled != null && enabled.contains(getPackageName());
    }

    private void showMessages() {
        if (list == null) return;
        list.removeAllViews();
        try {
            JSONArray items = new JSONArray(getSharedPreferences("message_archive", MODE_PRIVATE)
                    .getString("items", "[]"));
            if (items.length() == 0) {
                TextView empty = new TextView(this);
                empty.setText("Aucun message archivé pour le moment.");
                empty.setTextSize(16);
                list.addView(empty);
                return;
            }
            for (int i = items.length() - 1; i >= 0; i--) {
                JSONObject item = items.getJSONObject(i);
                TextView card = new TextView(this);
                card.setText("🕒 " + item.optString("time") + "\n"
                        + item.optString("title") + "\n"
                        + item.optString("body"));
                card.setTextSize(15);
                card.setTextColor(0xFF202020);
                card.setPadding(18, 18, 18, 18);
                card.setBackgroundColor(0xFFF0F3F8);
                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT);
                params.setMargins(0, 0, 0, 14);
                list.addView(card, params);
            }
        } catch (Exception e) {
            TextView error = new TextView(this);
            error.setText("Impossible de lire l'archive.");
            list.addView(error);
        }
    }
}
