WELLS MESSAGE BACKUP — VERSION SOURCE 1.0

Ce projet est un point de départ Android natif. Il archive localement le texte disponible
dans les notifications publiées par l'application WhatsApp officielle (com.whatsapp).

IMPORTANT
- L'utilisateur doit activer lui-même l'accès aux notifications Android.
- Utiliser uniquement sur son propre appareil/compte ou avec le consentement explicite
  de la personne concernée.
- L'application ne fonctionne pas en secret et n'accède pas directement aux conversations WhatsApp.
- Elle ne peut enregistrer que le texte réellement transmis dans une notification après activation.
- Si l'aperçu est masqué, si la notification est absente/regroupée, ou si le message est supprimé
  avant sa publication dans une notification, le texte peut manquer.
- Cette version ne sauvegarde pas de façon fiable les messages envoyés par le propriétaire du téléphone.
- Les données restent dans les préférences locales de l'application; aucune synchronisation serveur.
- Désinstaller l'application ou effacer ses données supprime l'archive.

OUVRIR / COMPILER
1. Ouvrir ce dossier dans Android Studio.
2. Laisser Gradle synchroniser le projet.
3. Compiler via Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Installer l'APK sur un appareil Android.
5. Ouvrir Wells Message Backup et choisir « Activer l'accès aux notifications ».
6. Dans les paramètres Android, autoriser Wells Message Backup.

Cette archive contient le CODE SOURCE, pas un APK déjà compilé.
